﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1
{
    public partial class FrmKategorije : Form
    {
        public FrmKategorije()
        {
            InitializeComponent();
        }

        List<Kategorija> kategorije;

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                var kat = new Kategorija();
                kat.Naziv = textBox1.Text;
                kat.Id = kategorije.Max(it => it.Id) + 1;
                kategorije.Add(kat);

                OsveziListu();
                textBox1.Text = "";
                textBox1.Focus();
            }
            else
                MessageBox.Show("Morate uneti naziv kategorije.");
        }

        private void OsveziListu()
        {
            listBox1.DataSource = null;
            listBox1.DataSource = kategorije;
        }

        private void FrmKategorije_Load(object sender, EventArgs e)
        {
            kategorije = Kategorija.Ucitaj();
            listBox1.DataSource = kategorije;
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                var kat = (Kategorija)listBox1.SelectedItem;
                kategorije.Remove(kat);
                OsveziListu();
            }
            else
                MessageBox.Show("Morate odabrati kategoriju za brisanje.");
        }

        private void FrmKategorije_FormClosing(object sender, FormClosingEventArgs e)
        {
            Kategorija.Sacuvaj(kategorije);
        }
    }
}
