﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat1
{
    public class Kategorija
    {
        public int Id { get; set; }

        public string Naziv { get; set; }

        public override string ToString()
        {
            return Naziv;
        }
        
        public static Kategorija StrToKategorija(string str)
        {
            
            try
            {
                var delovi = str.Split(';');
                var kat = new Kategorija();
                kat.Id = int.Parse(delovi[0]);
                kat.Naziv = delovi[1];
                return kat;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        const string imeFajla = "kategorije.txt";

        public static List<Kategorija> Ucitaj()
        {
            try
            {
                var kategorije = new List<Kategorija>();
                var sr = new StreamReader(imeFajla);
                while (!sr.EndOfStream)
                {
                    var red = sr.ReadLine();
                    var kat = Kategorija.StrToKategorija(red);
                    if (kat != null)
                        kategorije.Add(kat);
                }
                sr.Close();
                return kategorije;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static void Sacuvaj(List<Kategorija> kategorije)
        {
            var sw = new StreamWriter(imeFajla);
            foreach (var kat in kategorije)
                sw.WriteLine("{0};{1}", kat.Id, kat.Naziv);
            sw.Close();
        }
    }
}
