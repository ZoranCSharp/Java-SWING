﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat1
{
    public class Admin
    {
        public string KorIme { get; set; }

        public string Lozinka { get; set; }

        public static Admin StrToAdmin(string str)
        {
            // primer: zoki;zoki
            try
            {
                var delovi = str.Split(';');
                var a = new Admin();
                a.KorIme = delovi[0];
                a.Lozinka = delovi[1];
                return a;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        const string imeFajla = "admin.txt";

        public static List<Admin> Ucitaj()
        {
            try
            {
                var admin = new List<Admin>();
                var sr = new StreamReader(imeFajla);
                while (!sr.EndOfStream)
                {
                    var red = sr.ReadLine();
                    var a = Admin.StrToAdmin(red);
                    if (a != null)
                        admin.Add(a);
                }
                sr.Close();
                return admin;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static bool Postoji(string korIme, string lozinka)
        {
            var admini = Ucitaj();
            var ulogovani = admini.Where(a => a.KorIme == korIme && a.Lozinka == lozinka);
            return ulogovani.Count() == 1;
        }
    }
}
