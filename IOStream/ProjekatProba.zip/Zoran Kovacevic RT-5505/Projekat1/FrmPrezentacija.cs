﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1
{
    public partial class FrmPrezentacija : Form
    {
        public FrmPrezentacija()
        {
            InitializeComponent();
        }

        private void FrmPrezentacija_Load(object sender, EventArgs e)
        {
            slike = Slika.Ucitaj();
            autori = Autor.Ucitaj();
            kategorije = Kategorija.Ucitaj();
            lstSlike.DataSource = slike;
            cmbKategorije.DataSource = kategorije;
            cmbKategorije.SelectedItem = null;
        }

        private List<Slika> slike;
        private List<Autor> autori;
        private List<Kategorija> kategorije;

        private void btnPretraga_Click(object sender, EventArgs e)
        {
            Pretraga();
        }

        private void lstSlike_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstSlike.SelectedItem != null)
            {
                try
                {
                    var s = (Slika)lstSlike.SelectedItem;
                    picSlika.Image = Image.FromFile("Slike/" + s.ImeFajla);

                    var kat = kategorije.Where(k => k.Id == s.IdKategorije).FirstOrDefault();
                    if (kat != null)
                        lblKategorija.Text = "Kategorija: " + kat;
                    var autor = autori.Where(a => a.Id == s.IdAutora).FirstOrDefault();
                    if (autor != null)
                        lblAutor.Text = "Autor: " + autor;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Greska: " + ex.Message);
                }
            }
        }

        private void btnOceni_Click(object sender, EventArgs e)
        {
            if (lstSlike.SelectedItem != null)
            {
                if (cmbOcena.SelectedItem != null)
                {
                    int ocena = int.Parse(cmbOcena.SelectedItem.ToString());
                    var s = (Slika)lstSlike.SelectedItem;
                    Ocene.DodajOcenu(ocena, s.Id);
                    cmbOcena.SelectedItem = null;
                    MessageBox.Show("Uspesno ste ocenili sliku.");
                    if (OcenaSlike != null)
                        OcenaSlike(s.Id);
                }
                else
                    MessageBox.Show("Morate odabrati ocenu.");
            }
        }

        public static event OcenaSlike OcenaSlike;

        private void btnKategorijeSve_Click(object sender, EventArgs e)
        {
            cmbKategorije.SelectedItem = null;
            Pretraga();
        }

        private void cmbKategorije_SelectedIndexChanged(object sender, EventArgs e)
        {
            Pretraga();
        }

        private void Pretraga()
        {
            var kat = (Kategorija)cmbKategorije.SelectedItem;
            var rezultat = slike.Where(it => it.Naziv.Contains(txtPretraga.Text)
                && (kat == null || kat != null && it.IdKategorije == kat.Id));
            lstSlike.DataSource = rezultat.ToList();
            if (rezultat.Count() == 0)
            {
                picSlika.Image = null;
                lblAutor.Text = "Autor: ";
                lblKategorija.Text = "Kategorija: ";
                MessageBox.Show("Nije pronadjena nijedna slika.");
            }
        }
    }

    public delegate void OcenaSlike(int idSlike);
}
