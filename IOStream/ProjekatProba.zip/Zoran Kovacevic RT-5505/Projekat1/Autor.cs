﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat1
{
    public class Autor
    {
        public int Id { get; set; }

        public string Ime { get; set; }

        public string Prezime { get; set; }

        public DateTime DatumRodjenja { get; set; }

        public override string ToString()
        {
            return Ime + " " + Prezime + " (" + DatumRodjenja.ToShortDateString() + ")";
        }

        public static Autor StrToAutor(string str)
        {
            
            try
            {
                var delovi = str.Split(';');
                var a = new Autor();
                a.Id = int.Parse(delovi[0]);
                a.Ime = delovi[1];
                a.Prezime = delovi[2];
                a.DatumRodjenja = DateTime.Parse(delovi[3]);
                return a;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        const string imeFajla = "autori.txt";

        public static List<Autor> Ucitaj()
        {
            try
            {
                var autori = new List<Autor>();
                var sr = new StreamReader(imeFajla);
                while (!sr.EndOfStream)
                {
                    var red = sr.ReadLine();
                    var a = Autor.StrToAutor(red);
                    if (a != null)
                        autori.Add(a);
                }
                sr.Close();
                return autori;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static void Sacuvaj(List<Autor> autori)
        {
            var sw = new StreamWriter(imeFajla);
            foreach (var a in autori)
                sw.WriteLine("{0};{1};{2};{3}", a.Id, a.Ime, a.Prezime, a.DatumRodjenja);
            sw.Close();
        }
    }
}
