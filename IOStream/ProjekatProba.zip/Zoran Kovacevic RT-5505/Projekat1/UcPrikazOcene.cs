﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1
{
    public partial class UcPrikazOcene : UserControl
    {
        public UcPrikazOcene()
        {
            InitializeComponent();
        }

        public void ProsecnaOcena(List<int> ocene)
        {
            if (ocene.Count > 0)
            {
                double prosek = ocene.Average();
                pbOcena.Value = (int)Math.Round(prosek * 10);
                label1.Text = "Prosečna ocena slike " + prosek.ToString("0.0");
            }
            else
            {
                pbOcena.Value = pbOcena.Minimum;
                label1.Text = "Slika nije ocenjivana.";
            }
        }
    }
}
