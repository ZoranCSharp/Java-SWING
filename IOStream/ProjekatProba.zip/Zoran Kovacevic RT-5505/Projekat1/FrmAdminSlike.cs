﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1
{
    public partial class FrmAdminSlike : Form
    {
        public FrmAdminSlike()
        {
            InitializeComponent();

            FrmPrezentacija.OcenaSlike += frm_OcenaSlike;
        }

        void frm_OcenaSlike(int idSlike)
        {
            if (lstSlike.SelectedItem != null)
            {
                var s = (Slika)lstSlike.SelectedItem;
                if (s.Id == idSlike)
                    ucPrikazOcene.ProsecnaOcena(Ocene.UcitajZaSliku(s.Id));
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                var fi = new System.IO.FileInfo(openFileDialog1.FileName);
                putanjaSlike = openFileDialog1.FileName;
                txtFajl.Text = fi.Name;
            }
        }

        private string putanjaSlike;

        private List<Slika> slike;
        private List<Autor> autori;
        private List<Kategorija> kategorije;

        private void FrmAdminSlike_Load(object sender, EventArgs e)
        {
            autori = Autor.Ucitaj();
            cmbAutori.DataSource = autori;
            cmbAutori.SelectedIndex = -1;
            kategorije = Kategorija.Ucitaj();
            cmbKat.DataSource = kategorije;
            cmbKat.SelectedIndex = -1;

            slike = Slika.Ucitaj();
            lstSlike.DataSource = slike;
        }

        private void lstSlike_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstSlike.SelectedItem != null)
            {
                try
                {
                    var s = (Slika)lstSlike.SelectedItem;
                    picSlika.Image = Image.FromFile("Slike/" + s.ImeFajla);

                    var kat = kategorije.Where(k => k.Id == s.IdKategorije).FirstOrDefault();
                    if (kat != null)
                        lblKategorija.Text = "Kategorija: " + kat;
                    var autor = autori.Where(a => a.Id == s.IdAutora).FirstOrDefault();
                    if (autor != null)
                        lblAutor.Text = "Autor: " + autor;

                    ucPrikazOcene.ProsecnaOcena(Ocene.UcitajZaSliku(s.Id));
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Greska: " + ex.Message);
                }
            }
        }

        private void OsveziListu()
        {
            lstSlike.DataSource = null;
            lstSlike.DataSource = slike;
            txtPretraga.Text = "";
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            if (txtNaziv.Text != "" && cmbAutori.SelectedIndex != -1 && cmbKat.SelectedIndex != -1 &&
                txtFajl.Text != "")
            {
                try
                {
                    var s = new Slika();
                    s.Naziv = txtNaziv.Text;
                    var a = (Autor)cmbAutori.SelectedItem;
                    s.IdAutora = a.Id;
                    var k = (Kategorija)cmbKat.SelectedItem;
                    s.IdKategorije = k.Id;
                    s.ImeFajla = txtFajl.Text;
                    s.Id = slike.Max(it => it.Id) + 1;
                    slike.Add(s);
                    System.IO.File.Copy(putanjaSlike, "Slike/" + s.ImeFajla);

                    OsveziListu();
                    txtNaziv.Text = "";
                    cmbAutori.SelectedIndex = -1;
                    cmbKat.SelectedIndex = -1;
                    txtFajl.Text = "";
                    txtNaziv.Focus();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Greska: " + ex.Message);
                }
            }
            else
                MessageBox.Show("Morate uneti naziv, autora, kategoriju i putanju slike.");
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            if (lstSlike.SelectedItem != null)
            {
                try
                {
                    var s = (Slika)lstSlike.SelectedItem;
                    // System.IO.File.Delete("Slike/" + s.ImeFajla);
                    slike.Remove(s);
                    OsveziListu();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Greska: " + ex.Message);
                }
            }
            else
                MessageBox.Show("Morate odabrati sliku za brisanje.");
        }

        private void FrmAdminSlike_FormClosing(object sender, FormClosingEventArgs e)
        {
            Slika.Sacuvaj(slike);
        }

        private void btnPretraga_Click(object sender, EventArgs e)
        {
            var rezultat = slike.Where(it => it.Naziv.Contains(txtPretraga.Text));
            lstSlike.DataSource = rezultat.ToList();
            if (rezultat.Count() == 0)
                MessageBox.Show("Nije pronadjena nijedna slika.");
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void lblAutor_Click(object sender, EventArgs e)
        {

        }

        private void lblKategorija_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
