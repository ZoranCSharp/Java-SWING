﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1
{
    public partial class FrmAutori : Form
    {
        public FrmAutori()
        {
            InitializeComponent();
        }

        List<Autor> autori;

        private void FrmAutori_Load(object sender, EventArgs e)
        {
            autori = Autor.Ucitaj();
            lstAutori.DataSource = autori;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txtIme.Text != "" && txtPrezime.Text != "")
            {


               


                var a = new Autor();
                a.Ime = txtIme.Text;
                a.Prezime = txtPrezime.Text;
                a.DatumRodjenja = dtpDatumRodj.Value;
                a.Id = autori.Max(it => it.Id) + 1;

                //provera datuma 
                DateTime localDate = DateTime.Now;
                int result = DateTime.Compare(localDate, dtpDatumRodj.Value);
                if (result < 0)
                    MessageBox.Show("Pogresno unet datum");
                else autori.Add(a);

                OsveziListu();
                txtIme.Text = "";
                txtPrezime.Text = "";
                dtpDatumRodj.Value = DateTime.Now;

                

                txtIme.Focus();
            }
            else
                MessageBox.Show("Morate uneti ime i prezime autora.");
        }

        private void OsveziListu()
        {
            lstAutori.DataSource = null;
            lstAutori.DataSource = autori;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (lstAutori.SelectedItem != null)
            {
                var a = (Autor)lstAutori.SelectedItem;
                autori.Remove(a);
                OsveziListu();
            }
            else
                MessageBox.Show("Morate odabrati autora za brisanje.");
        }

        private void FrmAutori_FormClosing(object sender, FormClosingEventArgs e)
        {
            Autor.Sacuvaj(autori);
        }

        private void dtpDatumRodj_ValueChanged(object sender, EventArgs e)
        {
            DateTime localDate = DateTime.Now;

            int result = DateTime.Compare(localDate, dtpDatumRodj.Value);

            if (result < 0) MessageBox.Show("Pogresan datum vi se niste ni rodili!"); 
            else {} //ok
        }
    }
}
