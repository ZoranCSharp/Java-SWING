﻿namespace Projekat1
{
    partial class FrmPrezentacija
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPretraga = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPretraga = new System.Windows.Forms.TextBox();
            this.picSlika = new System.Windows.Forms.PictureBox();
            this.lstSlike = new System.Windows.Forms.ListBox();
            this.lblKategorija = new System.Windows.Forms.Label();
            this.lblAutor = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbOcena = new System.Windows.Forms.ComboBox();
            this.btnOceni = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbKategorije = new System.Windows.Forms.ComboBox();
            this.btnKategorijeSve = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picSlika)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPretraga
            // 
            this.btnPretraga.BackColor = System.Drawing.Color.Red;
            this.btnPretraga.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPretraga.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPretraga.Location = new System.Drawing.Point(205, 30);
            this.btnPretraga.Name = "btnPretraga";
            this.btnPretraga.Size = new System.Drawing.Size(75, 25);
            this.btnPretraga.TabIndex = 21;
            this.btnPretraga.Text = "Pretraži";
            this.btnPretraga.UseVisualStyleBackColor = false;
            this.btnPretraga.Click += new System.EventHandler(this.btnPretraga_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 18);
            this.label5.TabIndex = 20;
            this.label5.Text = "Naziv slike";
            // 
            // txtPretraga
            // 
            this.txtPretraga.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPretraga.Location = new System.Drawing.Point(12, 30);
            this.txtPretraga.Name = "txtPretraga";
            this.txtPretraga.Size = new System.Drawing.Size(187, 25);
            this.txtPretraga.TabIndex = 19;
            // 
            // picSlika
            // 
            this.picSlika.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picSlika.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picSlika.Location = new System.Drawing.Point(286, 14);
            this.picSlika.Name = "picSlika";
            this.picSlika.Size = new System.Drawing.Size(649, 499);
            this.picSlika.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picSlika.TabIndex = 18;
            this.picSlika.TabStop = false;
            // 
            // lstSlike
            // 
            this.lstSlike.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstSlike.FormattingEnabled = true;
            this.lstSlike.ItemHeight = 25;
            this.lstSlike.Location = new System.Drawing.Point(12, 124);
            this.lstSlike.Name = "lstSlike";
            this.lstSlike.Size = new System.Drawing.Size(268, 229);
            this.lstSlike.TabIndex = 17;
            this.lstSlike.SelectedIndexChanged += new System.EventHandler(this.lstSlike_SelectedIndexChanged);
            // 
            // lblKategorija
            // 
            this.lblKategorija.AutoSize = true;
            this.lblKategorija.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKategorija.Location = new System.Drawing.Point(12, 378);
            this.lblKategorija.Name = "lblKategorija";
            this.lblKategorija.Size = new System.Drawing.Size(71, 18);
            this.lblKategorija.TabIndex = 22;
            this.lblKategorija.Text = "Kategorija:";
            // 
            // lblAutor
            // 
            this.lblAutor.AutoSize = true;
            this.lblAutor.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAutor.Location = new System.Drawing.Point(12, 420);
            this.lblAutor.Name = "lblAutor";
            this.lblAutor.Size = new System.Drawing.Size(50, 18);
            this.lblAutor.TabIndex = 22;
            this.lblAutor.Text = "Autor: ";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(283, 522);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 18);
            this.label1.TabIndex = 23;
            this.label1.Text = "Ocena slike:";
            // 
            // cmbOcena
            // 
            this.cmbOcena.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmbOcena.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOcena.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbOcena.FormattingEnabled = true;
            this.cmbOcena.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cmbOcena.Location = new System.Drawing.Point(365, 519);
            this.cmbOcena.Name = "cmbOcena";
            this.cmbOcena.Size = new System.Drawing.Size(57, 26);
            this.cmbOcena.TabIndex = 24;
            // 
            // btnOceni
            // 
            this.btnOceni.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnOceni.BackColor = System.Drawing.Color.Red;
            this.btnOceni.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnOceni.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOceni.Location = new System.Drawing.Point(428, 517);
            this.btnOceni.Name = "btnOceni";
            this.btnOceni.Size = new System.Drawing.Size(75, 28);
            this.btnOceni.TabIndex = 25;
            this.btnOceni.Text = "Potvrdi";
            this.btnOceni.UseVisualStyleBackColor = false;
            this.btnOceni.Click += new System.EventHandler(this.btnOceni_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 18);
            this.label2.TabIndex = 27;
            this.label2.Text = "Kategorija";
            // 
            // cmbKategorije
            // 
            this.cmbKategorije.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.cmbKategorije.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbKategorije.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbKategorije.FormattingEnabled = true;
            this.cmbKategorije.Location = new System.Drawing.Point(12, 79);
            this.cmbKategorije.Name = "cmbKategorije";
            this.cmbKategorije.Size = new System.Drawing.Size(187, 26);
            this.cmbKategorije.TabIndex = 28;
            this.cmbKategorije.SelectedIndexChanged += new System.EventHandler(this.cmbKategorije_SelectedIndexChanged);
            // 
            // btnKategorijeSve
            // 
            this.btnKategorijeSve.BackColor = System.Drawing.Color.Red;
            this.btnKategorijeSve.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnKategorijeSve.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKategorijeSve.Location = new System.Drawing.Point(205, 79);
            this.btnKategorijeSve.Name = "btnKategorijeSve";
            this.btnKategorijeSve.Size = new System.Drawing.Size(75, 26);
            this.btnKategorijeSve.TabIndex = 29;
            this.btnKategorijeSve.Text = "Sve";
            this.btnKategorijeSve.UseVisualStyleBackColor = false;
            this.btnKategorijeSve.Click += new System.EventHandler(this.btnKategorijeSve_Click);
            // 
            // FrmPrezentacija
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.ClientSize = new System.Drawing.Size(947, 552);
            this.Controls.Add(this.btnKategorijeSve);
            this.Controls.Add(this.cmbKategorije);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnOceni);
            this.Controls.Add(this.cmbOcena);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblAutor);
            this.Controls.Add(this.lblKategorija);
            this.Controls.Add(this.btnPretraga);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtPretraga);
            this.Controls.Add(this.picSlika);
            this.Controls.Add(this.lstSlike);
            this.Name = "FrmPrezentacija";
            this.Text = "Prezentacija";
            this.Load += new System.EventHandler(this.FrmPrezentacija_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picSlika)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPretraga;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPretraga;
        private System.Windows.Forms.PictureBox picSlika;
        private System.Windows.Forms.ListBox lstSlike;
        private System.Windows.Forms.Label lblKategorija;
        private System.Windows.Forms.Label lblAutor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbOcena;
        private System.Windows.Forms.Button btnOceni;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbKategorije;
        private System.Windows.Forms.Button btnKategorijeSve;
    }
}