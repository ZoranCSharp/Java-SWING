﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat1
{
    public class Ocene
    {

        const string imeFajla = "ocene.txt";

        public static List<int> UcitajZaSliku(int idSlike)
        {
            try
            {
                var ocene = new List<int>();
                var sr = new StreamReader(imeFajla);
                while (!sr.EndOfStream)
                {
                    var red = sr.ReadLine();
                    // 2;4;5/5/2015
                    var delovi = red.Split(';');
                    if(int.Parse(delovi[0]) == idSlike)
                        ocene.Add(int.Parse(delovi[1]));
                }
                sr.Close();
                return ocene;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static void DodajOcenu(int ocena, int idSlike)
        {
            try
            {
                StreamWriter sw = new StreamWriter(imeFajla, true);
                sw.WriteLine("{0};{1};{2}", idSlike, ocena, DateTime.Now.ToShortDateString());
                sw.Close();
            }
            catch (Exception ex)
            {
            }
        }
    }
}
