﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat1
{
    public class Slika
    {
        public int Id { get; set; }

        public string Naziv { get; set; }

        public int IdAutora { get; set; }

        public int IdKategorije { get; set; }

        public string ImeFajla { get; set; }

        public override string ToString()
        {
            return Naziv;
        }

        public static Slika StrToSlika(string str)
        {
            
            try
            {
                var delovi = str.Split(';');
                var s = new Slika();
                s.Id = int.Parse(delovi[0]);
                s.Naziv = delovi[1];
                s.IdAutora = int.Parse(delovi[2]);
                s.IdKategorije = int.Parse(delovi[3]);
                s.ImeFajla = delovi[4];
                return s;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        const string imeFajla = "slike.txt";

        public static List<Slika> Ucitaj()
        {
            try
            {
                var slike = new List<Slika>();
                var sr = new StreamReader(imeFajla);
                while (!sr.EndOfStream)
                {
                    var red = sr.ReadLine();
                    var s = Slika.StrToSlika(red);
                    if (s != null)
                        slike.Add(s);
                }
                sr.Close();
                return slike;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static void Sacuvaj(List<Slika> slike)
        {
            var sw = new StreamWriter(imeFajla);
            foreach (var s in slike)
                sw.WriteLine("{0};{1};{2};{3};{4}", s.Id, s.Naziv, s.IdAutora, s.IdKategorije, s.ImeFajla);
            sw.Close();
        }
    }
}
